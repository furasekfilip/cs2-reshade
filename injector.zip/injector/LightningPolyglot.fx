// LightningPolyglot.fx - .fx <-> .dll bridge for Source2 lighting
// This is the "polyglot" pattern you meant: a .fx that is driven by a companion .dll/.addon
// The .fx itself is pure HLSL, the .dll is e.g. source2_cinematic_addon.cpp / source2_env_debug_addon.cpp
// They talk via ReShade uniform bridge (find_uniform_variable + set_uniform_value_float)
//
// How it works:
// 1. Drop LightningPolyglot.fx in reshade-shaders/
// 2. Build companion as .addon64 (or use built-in source/source2_env_debug_addon.cpp:1)
// 3. .dll pushes lighting values every frame in on_begin_effects:158, .fx reads them as uniforms
//
// No entity hooking (dwEntityList) needed - only engine2/rendersystemdx11 for lighting context.
// For true single-file PE+HLSL polyglot (file valid as both .dll and .fx), see comment at bottom - not recommended (AV, VAC).

#include "ReShade.fxh"

// --- pushed by .dll (addon) ---
// .dll finds these by name: runtime->find_uniform_variable(nullptr, "Poly_SkyColor") -> set_uniform_value_float
uniform float3 Poly_SkyColor < source = "poly_sky"; ui_label = "Sky Color (DLL)"; > = float3(0.85, 0.78, 0.62);
uniform float3 Poly_AmbientColor < source = "poly_ambient"; ui_label = "Ambient Color (DLL)"; > = float3(0.42, 0.38, 0.34);
uniform float3 Poly_FogColor < source = "poly_fog"; > = float3(0.82, 0.78, 0.68);
uniform float  Poly_FogDensity < source = "poly_fog_density"; > = 0.02;
uniform float  Poly_LightIntensity < source = "poly_light_intensity"; > = 1.0;
uniform float  Poly_Override < source = "poly_override"; > = 0.0; // 0 = use scene, 1 = use Poly_* colors

// --- local tuning (user can still tweak in ReShade UI) ---
uniform float Poly_Warmth < ui_type = "slider"; ui_min = 0.0; ui_max = 1.0; ui_label = "Warmth"; > = 0.5;
uniform float Poly_Exposure < ui_type = "slider"; ui_min = 0.5; ui_max = 2.0; ui_label = "Exposure"; > = 1.0;

float luminance(float3 c){ return dot(c, float3(0.2126,0.7152,0.0722)); }

float4 PS_PolyLight(float4 pos : SV_Position, float2 uv : TEXCOORD) : SV_Target
{
    float3 color = tex2D(ReShade::BackBuffer, uv).rgb;

    // Polyglot lighting: lerp scene toward DLL-provided sky/ambient based on luma
    // This is how .dll "changes lightning" without touching engine memory - pure post-process grade
    if (Poly_Override > 0.001)
    {
        float l = luminance(color);
        // highlights -> sky, shadows -> ambient (like Source2 env_light: sky + ambient cube)
        float t = smoothstep(0.3, 0.8, l);
        float3 skyTint = Poly_SkyColor / max(Poly_SkyColor, 0.001); // normalized tint, actual sky color divided by estimated
        float3 ambTint = Poly_AmbientColor / max(Poly_AmbientColor, 0.001);
        // but for demo we directly lerp to DLL colors weighted by override
        float3 grade = lerp(Poly_AmbientColor, Poly_SkyColor, t);
        // apply as tint, not replace: preserves detail
        color = lerp(color, color * (grade * 1.2), Poly_Override * 0.55);
        color *= lerp(1.0, Poly_LightIntensity, Poly_Override * 0.4);
    }

    // fog: simple depth-based (if depth available)
    #if __RENDERER__ != 0x9000
    float depth = ReShade::GetLinearizedDepth(uv);
    float fog = saturate(pow(depth, 1.1) * Poly_FogDensity * 8.0);
    color = lerp(color, Poly_FogColor, fog * (0.5 + Poly_Override * 0.5));
    #endif

    // warmth + exposure (local)
    float l = luminance(color);
    float3 warm = lerp(color * float3(0.78, 0.85, 1.05), color * float3(1.12, 0.92, 0.68), smoothstep(0.0, 0.7, l));
    color = lerp(color, warm, Poly_Warmth * 0.5);
    color *= Poly_Exposure;

    return float4(saturate(color), 1.0);
}

technique LightningPolyglot < ui_label = "Source2 - Lightning Polyglot (.fx <-> .dll)"; ui_tooltip = "Polyglot pattern: .fx reads uniforms pushed by companion .dll (source2_env_debug_addon.cpp). Enable .dll addon, then tune Poly_* in ReShade UI or let .dll auto-push sky/ambient."; >
{
    pass
    {
        VertexShader = PostProcessVS;
        PixelShader = PS_PolyLight;
    }
}

// --- Single-file PE+FX polyglot (concept, NOT shipped) ---
// A .fx is just text, a .dll is PE. You can craft a file that is valid as BOTH by starting with:
//   // MZ      <- HLSL line comment, but PE 'MZ' magic at byte 0
//   /* PE header bytes as comment block ... */
// Windows loader ignores HLSL, ReShade compiler ignores binary in comments.
// We don't do this: AV flags it, VAC hates it, and ReShade's official .addon64 mechanism (register_addon:251 in reshade.hpp) is the clean polyglot.
// Use the uniform bridge above instead - same effect, no hack.
