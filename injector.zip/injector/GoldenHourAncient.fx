// Golden Hour Ancient - Dedicated thumbnail match (alternative single-purpose file)
// If you prefer not to use combo, just enable this technique alone
// Same logic as Ancient mode in CyberpunkCinematic.fx, isolated for performance

#include "ReShade.fxh"

uniform float Source2_CinematicIntensity < source = "source2_intensity"; > = 1.0;
uniform bool Source2_IsLoading < source = "source2_loading"; > = false;
uniform int Source2_BuildNumber < source = "source2_build"; > = 0;

uniform float SunIntensity < ui_type = "slider"; ui_min = 0.0; ui_max = 2.0; > = 1.35;
uniform float Warmth < ui_type = "slider"; ui_min = 0.0; ui_max = 1.0; > = 0.72;
uniform float Haze < ui_type = "slider"; ui_min = 0.0; ui_max = 1.0; > = 0.35;
uniform float BloomStrength < ui_type = "slider"; ui_min = 0.0; ui_max = 1.5; > = 0.70;
uniform float GodrayStrength < ui_type = "slider"; ui_min = 0.0; ui_max = 1.0; > = 0.55;
uniform float2 SunPos < ui_type = "slider"; ui_min = 0.0; ui_max = 1.0; > = float2(0.52, 0.18);

float luminance(float3 c){return dot(c,float3(0.2126,0.7152,0.0722));}
float3 ACESFilm(float3 x){float a=2.51,b=0.03,c=2.43,d=0.59,e=0.14; return saturate((x*(a*x+b))/(x*(c*x+d)+e));}

float4 PS_Golden(float4 pos:SV_Position,float2 uv:TEXCOORD):SV_Target{
    float3 c = tex2D(ReShade::BackBuffer, uv).rgb;
    float intensity = saturate(Source2_CinematicIntensity);
    if(Source2_IsLoading) intensity*=0.2;
    if(intensity<0.001) return float4(c,1);
    // same golden logic - see CyberpunkCinematic.fx for commented version
    float l=luminance(c);
    c=pow(saturate(c),1.06);
    c=lerp(float3(l,l,l),c,1.12);
    // warm
    float t=smoothstep(0.15,0.75,l);
    c=lerp(c,c*float3(1.05,0.78,0.45)*(1-t)+c*float3(1.12,0.92,0.55)*t, Warmth*intensity);
    // bloom
    float2 px=ReShade::PixelSize;
    float3 b=0; b+=tex2D(ReShade::BackBuffer,uv+px).rgb; b+=tex2D(ReShade::BackBuffer,uv-px).rgb; b+=tex2D(ReShade::BackBuffer,uv+float2(px.x,-px.y)).rgb; b+=tex2D(ReShade::BackBuffer,uv+float2(-px.x,px.y)).rgb; b/=4;
    float m=smoothstep(0.70,1.0,luminance(b));
    c+=b*m*BloomStrength*SunIntensity*intensity*float3(1.15,0.95,0.65);
    // godrays
    float2 dir=uv-SunPos; float d=length(dir); float atten=exp(-d*2.2);
    float3 acc=0; for(int i=0;i<6;i++){float tt=float(i)/5.0; float2 sUV=lerp(uv,SunPos,tt*0.5); float lum=luminance(tex2D(ReShade::BackBuffer,sUV).rgb); acc+=smoothstep(0.6,1.0,lum)*exp(-tt*1.5);} acc/=6; c+=atten*luminance(acc)*GodrayStrength*float3(1.1,0.88,0.55)*intensity;
    // haze
    float haze=pow(saturate(1.0-length(uv-SunPos)),2.0)*Haze*0.25*intensity; c=lerp(c,float3(1.2,0.95,0.7)*1.1,haze);
    c=ACESFilm(c*0.95)*1.05; c=pow(c,1.0/1.08);
    // vignette + grain
    float2 p=uv*2-1; float v=1-dot(p,p)*0.18; v=pow(saturate(v),1.25); c*=lerp(1,v,0.45*intensity);
    float n=frac(sin(dot(uv*1.5+float(Source2_BuildNumber%997)*0.001,float2(12.9898,78.233)))*43758.5453); c+=(n-0.5)*0.08*0.18*intensity;
    return float4(saturate(c),1);
}
technique GoldenHourAncient < ui_label="Source2 - Golden Hour Ancient (Thumbnail)"; >{pass{VertexShader=PostProcessVS;PixelShader=PS_Golden;}}
