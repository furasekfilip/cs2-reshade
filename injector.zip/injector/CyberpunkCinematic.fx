// Cyberpunk 2077-like + Golden Hour Ancient - Source2 Cinematic via ReShade
// Pairs with source2_cinematic_addon.cpp (engine2.dll offsets)
// Now includes "Ancient" golden-hour preset matching thumbnail (stairs / desert sunset)
// Requires ReShade 6+ with depth buffer access (generic_depth_addon)

#include "ReShade.fxh"

// --- uniforms driven by addon (engine2 offsets) ---
uniform float Source2_CinematicIntensity < source = "source2_intensity"; > = 1.0;
uniform float2 Source2_Resolution < source = "source2_resolution"; > = float2(1920,1080);
uniform int Source2_BuildNumber < source = "source2_build"; > = 0;
uniform bool Source2_IsLoading < source = "source2_loading"; > = false;
// --- uniforms driven by Source2 Env Debug (built-in) ---
uniform float3 Source2_SkyColor < source = "sky_color"; > = float3(0.85, 0.78, 0.62);
uniform float3 Source2_AmbientColor < source = "ambient_color"; > = float3(0.42, 0.38, 0.34);
uniform float3 Source2_EnvOverrideSky < source = "override_sky"; > = float3(0.95, 0.75, 0.45);
uniform float3 Source2_EnvOverrideAmbient < source = "override_ambient"; > = float3(0.35, 0.32, 0.30);
uniform float Source2_EnvOverrideIntensity < source = "override_intensity"; > = 0.0;
uniform float3 Source2_FogColor < source = "fog_color"; > = float3(0.82, 0.78, 0.68);
uniform float Source2_FogDensity < source = "fog_density"; > = 0.02;

// --- shared tunables ---
uniform int Cinematic_Mode < ui_type = "combo"; ui_items = "Cyberpunk 2077\0Ancient - Golden Hour (Thumbnail)\0"; ui_label = "Cinematic Mode"; > = 1;

uniform float Cinematic_BloomStrength < ui_type = "slider"; ui_min = 0.0; ui_max = 1.5; ui_label = "Bloom Strength"; > = 0.65;
uniform float Cinematic_GrainStrength < ui_type = "slider"; ui_min = 0.0; ui_max = 1.0; ui_label = "Film Grain"; > = 0.18;
uniform float Cinematic_VignetteStrength < ui_type = "slider"; ui_min = 0.0; ui_max = 1.0; ui_label = "Vignette"; > = 0.45;
uniform bool Cinematic_Letterbox < ui_label = "Letterbox 2.39:1"; > = false;

uniform float Cinematic_Saturation < ui_type = "slider"; ui_min = 0.0; ui_max = 2.0; > = 1.12;
uniform float Cinematic_Contrast < ui_type = "slider"; ui_min = 0.5; ui_max = 1.5; > = 1.06;
uniform float Cinematic_BloomThreshold < ui_type = "slider"; ui_min = 0.5; ui_max = 1.0; > = 0.78;

// Ancient-specific
uniform float Ancient_SunIntensity < ui_type = "slider"; ui_min = 0.0; ui_max = 2.0; ui_label = "Sun Intensity (Ancient)"; > = 1.35;
uniform float Ancient_Warmth < ui_type = "slider"; ui_min = 0.0; ui_max = 1.0; ui_label = "Golden Warmth"; > = 0.72;
uniform float Ancient_Haze < ui_type = "slider"; ui_min = 0.0; ui_max = 1.0; ui_label = "Desert Haze"; > = 0.35;
uniform float Ancient_GodrayStrength < ui_type = "slider"; ui_min = 0.0; ui_max = 1.0; ui_label = "Godrays"; > = 0.55;
uniform float2 Ancient_SunPos < ui_type = "slider"; ui_min = 0.0; ui_max = 1.0; ui_label = "Sun Position"; > = float2(0.52, 0.18);

// Cyberpunk-specific
uniform float Cyberpunk_TealOrange < ui_type = "slider"; ui_min = 0.0; ui_max = 1.0; > = 0.55;

float luminance(float3 c) { return dot(c, float3(0.2126, 0.7152, 0.0722)); }

// ----- grading helpers -----
float3 grade_teal_orange(float3 c, float strength) {
    float luma = dot(c, float3(0.299, 0.587, 0.114));
    float3 warm = float3(1.08, 0.92, 0.68);
    float3 cool = float3(0.68, 0.88, 1.08);
    float t = smoothstep(0.0, 0.6, luma);
    float3 graded = lerp(c * cool, c * warm, t);
    return lerp(c, graded, strength * 0.55);
}

float3 grade_golden_hour(float3 c, float warmth) {
    // Thumbnail: sandy stone -> pushed to golden orange, sky -> warm amber, shadows -> deep brown
    // Lift shadows to warm, gain highlights to gold
    float l = luminance(c);
    // shadow tint (cool brown -> warm amber)
    float3 shadowTint = float3(1.05, 0.78, 0.45);
    float3 highlightTint = float3(1.12, 0.92, 0.55);
    float t = smoothstep(0.15, 0.75, l);
    float3 graded = lerp(c * shadowTint, c * highlightTint, t);
    // add subtle orange curve
    float3 orangeCurve = float3(1.0, 0.92, 0.82);
    graded = lerp(graded, graded * orangeCurve, 0.25 * warmth);
    // increase red in midtones like in thumbnail
    graded.r = lerp(graded.r, graded.r * 1.08, warmth * smoothstep(0.2, 0.8, l));
    return lerp(c, graded, warmth);
}

float3 sample_bloom(float2 uv, float radius) {
    float2 px = ReShade::PixelSize * radius;
    float3 s = 0;
    s += tex2D(ReShade::BackBuffer, uv + float2( px.x,  px.y)).rgb;
    s += tex2D(ReShade::BackBuffer, uv + float2(-px.x,  px.y)).rgb;
    s += tex2D(ReShade::BackBuffer, uv + float2( px.x, -px.y)).rgb;
    s += tex2D(ReShade::BackBuffer, uv + float2(-px.x, -px.y)).rgb;
    s += tex2D(ReShade::BackBuffer, uv + float2( px.x*2.0, 0)).rgb;
    s += tex2D(ReShade::BackBuffer, uv + float2(-px.x*2.0, 0)).rgb;
    return s / 6.0;
}

// anamorphic bloom + lens dirt
float3 bloom_ancient(float2 uv, float threshold, float strength) {
    float3 b1 = sample_bloom(uv, 1.0);
    float3 b2 = sample_bloom(uv, 2.2);
    float3 b3 = sample_bloom(uv, 4.0);
    float3 bloom = b1 * 0.5 + b2 * 0.35 + b3 * 0.15;
    float m = smoothstep(threshold, 1.0, luminance(bloom));
    bloom *= m * strength;
    // warm bloom tint - matches thumbnail sun
    bloom *= float3(1.15, 0.95, 0.65);
    return bloom;
}

float vignette(float2 uv, float strength) {
    float2 p = uv * 2.0 - 1.0;
    float v = 1.0 - dot(p, p) * 0.18;
    v = pow(saturate(v), 1.25);
    return lerp(1.0, v, strength);
}

float grain(float2 uv) {
    float n = frac(sin(dot(uv * 1.5 + float(Source2_BuildNumber % 997) * 0.001, float2(12.9898,78.233))) * 43758.5453);
    return (n - 0.5) * 0.08;
}

// godrays - radial blur towards sun (cheap volumetric light through stairs)
float godrays(float2 uv, float2 sunPos, float strength) {
    float2 dir = uv - sunPos;
    float dist = length(dir);
    float atten = exp(-dist * 2.2); // falloff from sun
    // sample along ray to sun - 6 taps
    float3 acc = 0;
    for (int i=0;i<6;i++) {
        float t = float(i)/5.0;
        float2 sUV = lerp(uv, sunPos, t * 0.5);
        float lum = luminance(tex2D(ReShade::BackBuffer, sUV).rgb);
        float m = smoothstep(0.6, 1.0, lum);
        acc += m * exp(-t*1.5);
    }
    acc /= 6.0;
    return atten * luminance(acc) * strength;
}

float3 ACESFilm(float3 x) {
    // Narkowicz ACES approx - for cinematic highlight rolloff like thumbnail
    float a = 2.51; float b = 0.03; float c = 2.43; float d = 0.59; float e = 0.14;
    return saturate((x*(a*x+b))/(x*(c*x+d)+e));
}

float4 PS_Cinematic(float4 pos : SV_Position, float2 uv : TEXCOORD) : SV_Target {
    float3 color = tex2D(ReShade::BackBuffer, uv).rgb;
    float intensity = saturate(Source2_CinematicIntensity);
    if (intensity < 0.001) return float4(color, 1.0);
    if (Source2_IsLoading) intensity *= 0.2;

    // base contrast/sat
    color = pow(saturate(color), Cinematic_Contrast);
    float l = luminance(color);
    color = lerp(float3(l,l,l), color, Cinematic_Saturation);

    if (Cinematic_Mode == 0) {
        // --- Cyberpunk path ---
        color = grade_teal_orange(color, Cyberpunk_TealOrange * intensity);
        float3 bloom = sample_bloom(uv, 1.0);
        float bloomMask = smoothstep(Cinematic_BloomThreshold, 1.0, luminance(bloom));
        bloom *= bloomMask * Cinematic_BloomStrength * intensity * 0.9;
        bloom *= float3(1.0, 0.95, 1.08);
        color += bloom;
    } else {
        // --- Ancient Golden Hour (Thumbnail) ---
        // 1. Golden grading
        color = grade_golden_hour(color, Ancient_Warmth * intensity);

        // 2. Lift sandstone texture - add micro contrast like thumbnail's wall on left
        // unsharp-like: subtle highpass boost
        float3 blur = sample_bloom(uv, 1.0);
        float3 highpass = color - blur;
        color += highpass * 0.18 * intensity; // enhances stone bumps

        // 3. Heavy sun bloom / glare at stairs top
        float3 bloom = bloom_ancient(uv, Cinematic_BloomThreshold - 0.08, Cinematic_BloomStrength * Ancient_SunIntensity);
        // add anamorphic streak near sun
        float anamorphic = 0;
        {
            float2 sunDir = normalize(uv - Ancient_SunPos);
            float streak = 1.0 - abs(dot(sunDir, float2(1,0)));
            streak = pow(saturate(streak), 32.0) * smoothstep(0.3, 0.0, length(uv - Ancient_SunPos));
            anamorphic = streak * 0.6 * Ancient_SunIntensity * intensity;
            bloom += anamorphic * float3(1.2, 0.9, 0.6);
        }
        color += bloom * intensity;

        // 4. Godrays from sun through doorway/stairs
        float rays = godrays(uv, Ancient_SunPos, Ancient_GodrayStrength);
        float depthFactor = 1.0;
        #if __RENDERER__ != 0x9000
        // if depth available, fade rays with depth (closer occludes)
        float depth = ReShade::GetLinearizedDepth(uv);
        depthFactor = saturate(1.0 - depth * 0.7); // farther = more rays visible like stairs receding
        #endif
        color += rays * float3(1.1, 0.88, 0.55) * intensity * depthFactor * 0.9;

        // 5. Desert haze / aerial perspective (warm fog towards sun) - driven by Env Debug if override active
        float3 fogCol = lerp(float3(1.2, 0.95, 0.7) * 1.1, Source2_FogColor, Source2_EnvOverrideIntensity * 0.5);
        float haze = pow(saturate(1.0 - length(uv - Ancient_SunPos)), 2.0) * lerp(Ancient_Haze, Source2_FogDensity * 8.0, Source2_EnvOverrideIntensity * 0.5) * 0.25 * intensity;
        color = lerp(color, fogCol, haze);
        // distance fog via depth
        #if __RENDERER__ != 0x9000
        float fog = saturate(pow(depth, 1.5) * lerp(Ancient_Haze, Source2_FogDensity * 8.0, Source2_EnvOverrideIntensity * 0.3) * 0.35 * intensity);
        float3 distFogCol = lerp(float3(0.98, 0.88, 0.72), Source2_FogColor, Source2_EnvOverrideIntensity * 0.4);
        color = lerp(color, distFogCol, fog);
        #endif
        // 5b. Optional sky/ambient override tint (lets Env Debug color grade the whole scene like Source2 env_light)
        if (Source2_EnvOverrideIntensity > 0.001) {
            float lum = luminance(color);
            float3 skyTint = Source2_EnvOverrideSky / max(Source2_SkyColor, 0.001);
            float3 ambTint = Source2_EnvOverrideAmbient / max(Source2_AmbientColor, 0.001);
            float t = smoothstep(0.35, 0.85, lum); // highlights get sky, shadows get ambient
            float3 tint = lerp(ambTint, skyTint, t);
            color *= lerp(1.0, tint, Source2_EnvOverrideIntensity * 0.35 * intensity);
        }

        // 6. ACES tonemap for highlight rolloff (sun not clipped harshly)
        color = ACESFilm(color * 0.95) * 1.05;
        // bring back some brightness after ACES
        color = pow(color, 1.0/1.08);
    }

    // --- common post (both modes) ---
    color *= vignette(uv, Cinematic_VignetteStrength * intensity);
    color += grain(uv) * Cinematic_GrainStrength * intensity * (Cinematic_Mode==1? 0.7:1.0);

    if (Cinematic_Letterbox) {
        float aspect = ReShade::ScreenSize.x / ReShade::ScreenSize.y;
        float target = 2.39;
        if (aspect < target) {
            float h = ReShade::ScreenSize.y * (1.0 - (aspect/target));
            float bar = h / ReShade::ScreenSize.y * 0.5;
            if (uv.y < bar || uv.y > 1.0 - bar) color *= 0.0;
        } else {
            if (uv.y < 0.07 || uv.y > 0.93) color *= 0.0;
        }
    }

    if (Source2_IsLoading) {
        color = lerp(color, float3(l,l,l), 0.35);
    }

    return float4(saturate(color), 1.0);
}

technique CyberpunkCinematic < ui_label = "Source2 - Cinematic (Cyberpunk / Ancient)"; ui_tooltip = "Matches thumbnail: switch Mode to 'Ancient - Golden Hour'. Driven by engine2.dll offsets (window size/build/signOnState). Use Source2EnvDebug overlay to tune sky/ambient."; > {
    pass {
        VertexShader = PostProcessVS;
        PixelShader = PS_Cinematic;
    }
}
