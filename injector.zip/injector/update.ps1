# Auto-update injector folder with latest builds
# Run after each `cmake --build` — keeps ReShade32.dll / ReShade64.dll + injectors in sync
param()
$ErrorActionPreference="Stop"
$root = Split-Path $PSScriptRoot -Parent
$build64 = Join-Path $root "..\..\build\Release\ReShade64.dll"
$build32 = Join-Path $root "..\..\build32\Release\ReShade32.dll"
# fallback to build\Release if using single build dir
if (!(Test-Path $build64)) { $build64 = Join-Path $root "..\..\build\Release\ReShade64.dll" }
if (!(Test-Path $build32)) { $build32 = Join-Path $root "..\..\build32\Release\ReShade32.dll" }

# cmake builds -> injector folder
if (Test-Path "$root\build\Release\ReShade64.dll") { Copy-Item "$root\build\Release\ReShade64.dll" "$PSScriptRoot\ReShade64.dll" -Force; Write-Host "updated ReShade64.dll" }
if (Test-Path "$root\build32\Release\ReShade32.dll") { Copy-Item "$root\build32\Release\ReShade32.dll" "$PSScriptRoot\ReShade32.dll" -Force; Write-Host "updated ReShade32.dll" }
# also from cmake build dirs at workspace root
if (Test-Path "C:\Users\Filip\Downloads\unviersalreshade\build\Release\ReShade64.dll") { Copy-Item "C:\Users\Filip\Downloads\unviersalreshade\build\Release\ReShade64.dll" "$PSScriptRoot\ReShade64.dll" -Force; Write-Host "synced ReShade64.dll" }
if (Test-Path "C:\Users\Filip\Downloads\unviersalreshade\build32\Release\ReShade32.dll") { Copy-Item "C:\Users\Filip\Downloads\unviersalreshade\build32\Release\ReShade32.dll" "$PSScriptRoot\ReShade32.dll" -Force; Write-Host "synced ReShade32.dll" }

# injectors from legacy bin/ (built via .sln, rarely changes)
if (Test-Path "$root\bin\x64\Release\inject.exe") { Copy-Item "$root\bin\x64\Release\inject.exe" "$PSScriptRoot\inject_x64.exe" -Force; Write-Host "synced inject_x64.exe" }
if (Test-Path "$root\bin\Win32\Release\inject.exe") { Copy-Item "$root\bin\Win32\Release\inject.exe" "$PSScriptRoot\inject_x32.exe" -Force; Write-Host "synced inject_x32.exe" }
# also sync FX/preset (embedded but also copied for convenience)
if (Test-Path "$root\examples\20-source2-cinematic\CyberpunkCinematic.fx") { Copy-Item "$root\examples\20-source2-cinematic\CyberpunkCinematic.fx" "$PSScriptRoot\" -Force; Copy-Item "$root\examples\20-source2-cinematic\GoldenHourAncient.fx" "$PSScriptRoot\" -Force; Copy-Item "$root\examples\20-source2-cinematic\LightningPolyglot.fx" "$PSScriptRoot\" -Force; Copy-Item "$root\examples\20-source2-cinematic\Ancient_GoldenHour_Preset.ini" "$PSScriptRoot\" -Force; Write-Host "synced FX + preset" }

Get-ChildItem $PSScriptRoot | Format-Table Name, Length, LastWriteTime
Write-Host "injector folder now has latest version always - just re-run update.ps1 after each build"
