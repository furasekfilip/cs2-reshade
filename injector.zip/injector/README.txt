ReShade Injector - always latest

Contents (auto-synced via update.ps1):
  ReShade64.dll  - x64 build (build/Release) with Source2 Env Debug builtin
  ReShade32.dll  - x32 build (build32/Release)
  inject_x64.exe - x64 injector (bin/x64/Release/inject.exe)
  inject_x32.exe - x32 injector (bin/Win32/Release/inject.exe)

Usage:
  inject_x64.exe <process.exe> ReShade64.dll
  inject_x32.exe <process.exe> ReShade32.dll
  e.g. inject_x64.exe cs2.exe ReShade64.dll

Or drop ReShade64.dll as dxgi.dll next to game exe.

Keep latest:
  powershell -ExecutionPolicy Bypass -File update.ps1
  (also runs automatically if you build via cmake — just re-run after each build)

Built: 2026-08-28 ReShade with source2_env_debug_addon + cinematic shaders
